// What to Watch: käyttöliittymä. Kaikki ehdotukset tulevat palvelimelta, joka on tarkistanut saatavuuden.
const $ = (id) => document.getElementById(id);

const SERVICES = ["Netflix", "Disney+", "HBO Max", "Prime Video", "Apple TV", "Yle Areena", "Ruutu", "MTV Katsomo", "Viaplay", "SkyShowtime", "Paramount+", "Hulu", "Peacock", "BBC iPlayer", "Crunchyroll", "Mubi"];
const COUNTRIES = "FI SE NO DK IS EE LV LT DE AT CH NL BE FR GB IE ES PT IT PL CZ GR HU RO US CA MX BR AR CL CO AU NZ JP KR IN ZA".split(" ");
const MOODS = ["Thrilling", "Funny", "Touching", "Calm", "Crime", "Sci-fi", "Horror", "Romance", "Documentary", "Animation", "With family", "Short", "True story"];
const RATES = [0, 7, 12, 16, 18];
const RLAB = ["S", "K7", "K12", "K16", "K18"];

const T = {
  fi: {
    lang: "Kieli", lead: "Kerro ikäsi, maasi ja palvelusi. Ehdotamme vain nimikkeitä, jotka palvelin on tarkistanut löytyvän valitsemistasi palveluista omassa maassasi.",
    age: "Ikä", country: "Maa", services: "Sinulla olevat suoratoistopalvelut", kind: "Mitä haluat katsoa?", mood: "Fiilis", wish: "Toive omin sanoin (valinnainen)",
    wishPh: "esim. jännittävä mutta ei liian synkkä", rate: "Ikärajat", rateOn: "Käytä rajausta", both: "Kaikki", film: "Elokuvat", series: "Sarjat",
    go: "Ehdota", busy: "Haetaan…", rateAll: "Kaikki ikärajat", rateOnly: (a) => "Vain " + a, rateRange: (a, b) => a + " – " + b,
    status: { start: "Aloitetaan…", browse: "Selataan palvelujesi tarjontaa…", check: "Tarkistetaan nimikkeitä…", verify: "Varmistetaan saatavuus…" },
    needServ: "Valitse vähintään yksi palvelu.", needAge: "Anna ikä (1–120).", none: "Tähän hakuun ei löytynyt tarkistettuja osumia. Kokeile väljempää rajausta tai toista fiilistä.",
    unmatched: (l) => "Näitä palveluja ei löytynyt maastasi, joten ne jätettiin pois: " + l,
    errors: { config: "Palvelin ei ole vielä valmis (avaimet puuttuvat).", busy: "Palvelu on juuri nyt kuormittunut. Yritä hetken päästä uudelleen.", limit: "Liian monta hakua. Yritä myöhemmin uudelleen.", no_services: "Mitään valitsemistasi palveluista ei löytynyt tästä maasta.", agent: "Haku epäonnistui. Yritä uudelleen.", tmdb: "Saatavuustietoja ei saatu juuri nyt. Yritä uudelleen.", upstream: "Yhteysvirhe. Yritä uudelleen.", bad_request: "Tarkista syötteet." },
    film1: "Elokuva", series1: "Sarja", seasons: (n) => n + " kautta", min: (n) => n + " min", where: "Katsottavissa tilauksella: ", watch: "Avaa saatavuus", approx: "arvio USA:n luokituksesta", rating: "arvosana", votes: "ääntä",
    attr: "Saatavuustiedot: JustWatch. Tämä tuote käyttää TMDB:n rajapintaa, mutta TMDB ei ole sen hyväksymä tai sertifioima. Ikärajat ovat oman maasi luokitus, kun se on saatavilla."
  },
  en: {
    lang: "Language", lead: "Tell us your age, country and services. We only suggest titles our server has checked are included in the services you picked, in your country.",
    age: "Age", country: "Country", services: "Your streaming services", kind: "What do you feel like?", mood: "Mood", wish: "Anything else (optional)",
    wishPh: "e.g. thrilling but not too dark", rate: "Age ratings", rateOn: "Limit by rating", both: "Anything", film: "Films", series: "Series",
    go: "Suggest", busy: "Searching…", rateAll: "All ratings", rateOnly: (a) => "Only " + a, rateRange: (a, b) => a + " – " + b,
    status: { start: "Starting…", browse: "Browsing your services' catalogues…", check: "Checking titles…", verify: "Verifying availability…" },
    needServ: "Pick at least one service.", needAge: "Enter an age (1–120).", none: "No verified matches for this search. Try wider limits or another mood.",
    unmatched: (l) => "These services were not found in your country and were left out: " + l,
    errors: { config: "The server isn't set up yet (keys missing).", busy: "The service is busy right now. Please try again shortly.", limit: "Too many searches. Please try again later.", no_services: "None of your selected services exist in this country.", agent: "The search failed. Please try again.", tmdb: "Availability data is unavailable right now. Please try again.", upstream: "Connection problem. Please try again.", bad_request: "Please check your inputs." },
    film1: "Film", series1: "Series", seasons: (n) => n + (n === 1 ? " season" : " seasons"), min: (n) => n + " min", where: "Included with: ", watch: "Open availability", approx: "estimated from US rating", rating: "rating", votes: "votes",
    attr: "Availability data by JustWatch. This product uses the TMDB API but is not endorsed or certified by TMDB. Age ratings are those of your country when available."
  },
  sv: {
    lang: "Språk", lead: "Ange ålder, land och tjänster. Vi föreslår bara titlar som servern har kontrollerat finns hos dina valda tjänster i ditt land.",
    age: "Ålder", country: "Land", services: "Dina streamingtjänster", kind: "Vad vill du se?", mood: "Stämning", wish: "Önskemål (valfritt)",
    wishPh: "t.ex. spännande men inte för mörkt", rate: "Åldersgränser", rateOn: "Begränsa", both: "Allt", film: "Filmer", series: "Serier",
    go: "Föreslå", busy: "Söker…", rateAll: "Alla åldersgränser", rateOnly: (a) => "Endast " + a, rateRange: (a, b) => a + " – " + b,
    status: { start: "Startar…", browse: "Bläddrar i utbudet…", check: "Kontrollerar titlar…", verify: "Bekräftar tillgänglighet…" },
    needServ: "Välj minst en tjänst.", needAge: "Ange en ålder (1–120).", none: "Inga verifierade träffar. Prova bredare gränser eller en annan stämning.",
    unmatched: (l) => "Dessa tjänster finns inte i ditt land och utelämnades: " + l,
    errors: { config: "Servern är inte konfigurerad än.", busy: "Tjänsten är upptagen. Försök igen strax.", limit: "För många sökningar. Försök senare.", no_services: "Ingen av dina tjänster finns i det här landet.", agent: "Sökningen misslyckades. Försök igen.", tmdb: "Tillgänglighetsdata saknas just nu.", upstream: "Anslutningsfel. Försök igen.", bad_request: "Kontrollera uppgifterna." },
    film1: "Film", series1: "Serie", seasons: (n) => n + (n === 1 ? " säsong" : " säsonger"), min: (n) => n + " min", where: "Ingår hos: ", watch: "Visa tillgänglighet", approx: "uppskattat från USA:s klassning", rating: "betyg", votes: "röster",
    attr: "Tillgänglighetsdata från JustWatch. Produkten använder TMDB:s API men är inte godkänd av TMDB."
  },
  de: {
    lang: "Sprache", lead: "Nenne Alter, Land und Dienste. Wir schlagen nur Titel vor, bei denen der Server geprüft hat, dass sie in deinen gewählten Diensten in deinem Land enthalten sind.",
    age: "Alter", country: "Land", services: "Deine Streaming-Dienste", kind: "Worauf hast du Lust?", mood: "Stimmung", wish: "Wunsch (optional)",
    wishPh: "z. B. spannend, aber nicht zu düster", rate: "Altersfreigabe", rateOn: "Einschränken", both: "Alles", film: "Filme", series: "Serien",
    go: "Vorschlagen", busy: "Suche läuft…", rateAll: "Alle Freigaben", rateOnly: (a) => "Nur " + a, rateRange: (a, b) => a + " – " + b,
    status: { start: "Start…", browse: "Angebote werden durchsucht…", check: "Titel werden geprüft…", verify: "Verfügbarkeit wird bestätigt…" },
    needServ: "Wähle mindestens einen Dienst.", needAge: "Alter eingeben (1–120).", none: "Keine geprüften Treffer. Versuche weitere Grenzen oder eine andere Stimmung.",
    unmatched: (l) => "Diese Dienste gibt es in deinem Land nicht und wurden weggelassen: " + l,
    errors: { config: "Der Server ist noch nicht eingerichtet.", busy: "Der Dienst ist ausgelastet. Bitte gleich erneut versuchen.", limit: "Zu viele Suchen. Bitte später erneut.", no_services: "Keiner deiner Dienste ist in diesem Land verfügbar.", agent: "Suche fehlgeschlagen. Bitte erneut versuchen.", tmdb: "Verfügbarkeitsdaten gerade nicht erreichbar.", upstream: "Verbindungsproblem. Bitte erneut versuchen.", bad_request: "Bitte Eingaben prüfen." },
    film1: "Film", series1: "Serie", seasons: (n) => n + (n === 1 ? " Staffel" : " Staffeln"), min: (n) => n + " Min.", where: "Enthalten bei: ", watch: "Verfügbarkeit öffnen", approx: "geschätzt nach US-Einstufung", rating: "Bewertung", votes: "Stimmen",
    attr: "Verfügbarkeitsdaten von JustWatch. Dieses Produkt nutzt die TMDB-API, wird aber nicht von TMDB unterstützt."
  },
  es: {
    lang: "Idioma", lead: "Indica tu edad, país y servicios. Solo sugerimos títulos que el servidor ha comprobado que están incluidos en tus servicios en tu país.",
    age: "Edad", country: "País", services: "Tus servicios de streaming", kind: "¿Qué te apetece?", mood: "Ánimo", wish: "Deseo (opcional)",
    wishPh: "p. ej. emocionante pero no muy oscuro", rate: "Clasificación por edad", rateOn: "Limitar", both: "Todo", film: "Películas", series: "Series",
    go: "Sugerir", busy: "Buscando…", rateAll: "Todas las clasificaciones", rateOnly: (a) => "Solo " + a, rateRange: (a, b) => a + " – " + b,
    status: { start: "Empezando…", browse: "Explorando el catálogo…", check: "Comprobando títulos…", verify: "Verificando disponibilidad…" },
    needServ: "Elige al menos un servicio.", needAge: "Introduce una edad (1–120).", none: "Sin resultados verificados. Prueba límites más amplios u otro ánimo.",
    unmatched: (l) => "Estos servicios no existen en tu país y se omitieron: " + l,
    errors: { config: "El servidor aún no está configurado.", busy: "Servicio ocupado. Inténtalo en un momento.", limit: "Demasiadas búsquedas. Inténtalo más tarde.", no_services: "Ninguno de tus servicios existe en este país.", agent: "La búsqueda falló. Inténtalo de nuevo.", tmdb: "Datos de disponibilidad no disponibles ahora.", upstream: "Error de conexión. Inténtalo de nuevo.", bad_request: "Revisa los datos." },
    film1: "Película", series1: "Serie", seasons: (n) => n + (n === 1 ? " temporada" : " temporadas"), min: (n) => n + " min", where: "Incluido en: ", watch: "Ver disponibilidad", approx: "estimado según clasificación de EE. UU.", rating: "nota", votes: "votos",
    attr: "Datos de disponibilidad de JustWatch. Este producto usa la API de TMDB pero no está respaldado por TMDB."
  },
  fr: {
    lang: "Langue", lead: "Indiquez votre âge, pays et services. Nous ne proposons que des titres dont le serveur a vérifié la présence dans vos services, dans votre pays.",
    age: "Âge", country: "Pays", services: "Vos services de streaming", kind: "Envie de quoi ?", mood: "Ambiance", wish: "Envie particulière (facultatif)",
    wishPh: "ex. haletant mais pas trop sombre", rate: "Classification d'âge", rateOn: "Limiter", both: "Tout", film: "Films", series: "Séries",
    go: "Suggérer", busy: "Recherche…", rateAll: "Toutes classifications", rateOnly: (a) => "Seulement " + a, rateRange: (a, b) => a + " – " + b,
    status: { start: "Démarrage…", browse: "Exploration des catalogues…", check: "Vérification des titres…", verify: "Confirmation de la disponibilité…" },
    needServ: "Choisissez au moins un service.", needAge: "Saisissez un âge (1–120).", none: "Aucun résultat vérifié. Essayez des limites plus larges ou une autre ambiance.",
    unmatched: (l) => "Ces services n'existent pas dans votre pays et ont été ignorés : " + l,
    errors: { config: "Le serveur n'est pas encore configuré.", busy: "Service occupé. Réessayez dans un instant.", limit: "Trop de recherches. Réessayez plus tard.", no_services: "Aucun de vos services n'existe dans ce pays.", agent: "La recherche a échoué. Réessayez.", tmdb: "Données de disponibilité indisponibles.", upstream: "Problème de connexion. Réessayez.", bad_request: "Vérifiez les champs." },
    film1: "Film", series1: "Série", seasons: (n) => n + (n === 1 ? " saison" : " saisons"), min: (n) => n + " min", where: "Inclus chez : ", watch: "Voir la disponibilité", approx: "estimé d'après la classification US", rating: "note", votes: "votes",
    attr: "Données de disponibilité par JustWatch. Ce produit utilise l'API TMDB mais n'est ni approuvé ni certifié par TMDB."
  }
};
const MOOD_L = {
  fi: ["Jännittävä", "Hauska", "Liikuttava", "Rauhallinen", "Rikos", "Scifi", "Kauhu", "Romantiikka", "Dokumentti", "Animaatio", "Koko perheelle", "Lyhyt", "Tositapahtumiin perustuva"],
  en: MOODS,
  sv: ["Spännande", "Rolig", "Rörande", "Lugn", "Kriminal", "Sci-fi", "Skräck", "Romantik", "Dokumentär", "Animation", "För hela familjen", "Kort", "Sann historia"],
  de: ["Spannend", "Lustig", "Berührend", "Ruhig", "Krimi", "Sci-Fi", "Horror", "Romantik", "Doku", "Animation", "Für die Familie", "Kurz", "Wahre Geschichte"],
  es: ["Emocionante", "Divertida", "Emotiva", "Tranquila", "Crimen", "Ciencia ficción", "Terror", "Romance", "Documental", "Animación", "Para toda la familia", "Corta", "Historia real"],
  fr: ["Haletant", "Drôle", "Touchant", "Calme", "Policier", "Science-fiction", "Horreur", "Romance", "Documentaire", "Animation", "En famille", "Court", "Histoire vraie"]
};

const store = {
  get(k, d) { try { const v = localStorage.getItem("wtw:" + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("wtw:" + k, JSON.stringify(v)); } catch { /* ei tallennusta */ } }
};

const st = {
  lang: store.get("lang", null) || ((navigator.language || "en").slice(0, 2)),
  services: new Set(store.get("services", [])),
  moods: new Set(store.get("moods", [])),
  kind: store.get("kind", "both"),
  seen: store.get("seen", [])
};
if (!T[st.lang]) st.lang = "en";
const t = () => T[st.lang];

/* ---------- rakenne ---------- */
function buildServices() {
  const box = $("services");
  box.textContent = "";
  for (const s of SERVICES) {
    const b = document.createElement("button");
    b.type = "button"; b.className = "chip"; b.textContent = s;
    b.setAttribute("aria-pressed", st.services.has(s));
    b.onclick = () => { st.services.has(s) ? st.services.delete(s) : st.services.add(s); b.setAttribute("aria-pressed", st.services.has(s)); store.set("services", [...st.services]); };
    box.append(b);
  }
}
function buildMoods() {
  const box = $("moods");
  box.textContent = "";
  MOODS.forEach((m, i) => {
    const b = document.createElement("button");
    b.type = "button"; b.className = "chip"; b.textContent = MOOD_L[st.lang][i];
    b.setAttribute("aria-pressed", st.moods.has(m));
    b.onclick = () => { st.moods.has(m) ? st.moods.delete(m) : st.moods.add(m); b.setAttribute("aria-pressed", st.moods.has(m)); store.set("moods", [...st.moods]); };
    box.append(b);
  });
}
function buildKind() {
  const box = $("kind");
  box.textContent = "";
  for (const k of ["both", "film", "series"]) {
    const b = document.createElement("button");
    b.type = "button"; b.setAttribute("role", "radio"); b.textContent = t()[k];
    b.setAttribute("aria-checked", st.kind === k);
    b.onclick = () => { st.kind = k; store.set("kind", k); buildKind(); };
    box.append(b);
  }
}
function buildCountries() {
  const sel = $("country");
  let dn = null;
  try { dn = new Intl.DisplayNames([st.lang], { type: "region" }); } catch { /* koodit */ }
  const prev = sel.value || store.get("country", null);
  const list = COUNTRIES.map((c) => [c, dn ? dn.of(c) : c]).sort((a, b) => a[1].localeCompare(b[1], st.lang));
  sel.textContent = "";
  for (const [c, n] of list) { const o = document.createElement("option"); o.value = c; o.textContent = n; sel.append(o); }
  sel.value = prev || "FI";
}

function rateState() {
  let lo = +$("rMin").value, hi = +$("rMax").value;
  if (lo > hi) [lo, hi] = [hi, lo];
  return { lo, hi };
}
function drawRate() {
  const { lo, hi } = rateState();
  const on = $("rateOn").checked;
  $("rateBox").classList.toggle("off", !on);
  $("fill").style.left = (lo / 4) * 100 + "%";
  $("fill").style.width = ((hi - lo) / 4) * 100 + "%";
  $("rateTxt").textContent = !on ? t().rateAll : lo === hi ? t().rateOnly(RLAB[lo]) : t().rateRange(RLAB[lo], RLAB[hi]);
  store.set("rate", { on, lo, hi });
}

function applyLang() {
  const x = t();
  document.documentElement.lang = st.lang;
  $("uiLang").value = st.lang;
  $("lblLang").textContent = x.lang;
  $("lead").textContent = x.lead;
  $("lAge").textContent = x.age; $("lCountry").textContent = x.country;
  $("hServices").textContent = x.services; $("hKind").textContent = x.kind; $("hMood").textContent = x.mood;
  $("lWish").textContent = x.wish; $("wish").placeholder = x.wishPh;
  $("hRate").textContent = x.rate; $("lRateOn").textContent = x.rateOn;
  $("go").textContent = x.go;
  $("attr").textContent = x.attr;
  buildKind(); buildMoods(); buildCountries(); drawRate();
  store.set("lang", st.lang);
}

/* ---------- tulokset ---------- */
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
function safeUrl(u) { try { const x = new URL(u); return x.protocol === "https:" ? x.href : null; } catch { return null; } }

function card(it) {
  const x = t();
  const a = el("article", "item");
  const img = el("img", "poster");
  img.alt = ""; img.loading = "lazy";
  const p = safeUrl(it.poster);
  if (p && p.startsWith("https://image.tmdb.org/")) img.src = p;
  a.append(img);
  const body = el("div");
  body.append(el("h3", null, it.title + (it.year ? " (" + it.year + ")" : "")));
  const meta = el("p", "meta");
  if (it.age != null) {
    const b = el("span", "badge", it.age === 0 ? "S" : "K" + it.age + (it.ageApprox ? "~" : ""));
    if (it.ageApprox) b.title = x.approx;
    meta.append(b);
  }
  const parts = [it.kind === "movie" ? x.film1 : x.series1];
  if (it.genres && it.genres.length) parts.push(it.genres.slice(0, 3).join(", "));
  if (it.runtimeMin) parts.push(x.min(it.runtimeMin));
  if (it.seasons) parts.push(x.seasons(it.seasons));
  if (it.vote) parts.push("TMDB " + it.vote.toFixed(1) + "/10");
  meta.append(document.createTextNode(parts.join(" · ")));
  body.append(meta);
  if (it.why) body.append(el("p", "why", it.why));
  body.append(el("p", "where", x.where + (it.services || []).join(", ")));
  const links = el("div", "links");
  for (const [u, label] of [[it.imdbUrl, "IMDb"], [it.watchUrl, x.watch]]) {
    const s = safeUrl(u);
    if (!s) continue;
    const l = el("a", null, label);
    l.href = s; l.target = "_blank"; l.rel = "noopener noreferrer";
    links.append(l);
  }
  body.append(links);
  a.append(body);
  return a;
}

function showResult(res) {
  const box = $("results");
  box.textContent = "";
  const x = t();
  if (res.unmatched && res.unmatched.length) box.append(el("p", "note", x.unmatched(res.unmatched.join(", "))));
  if (!res.items.length) { box.append(el("p", "note", x.none)); return; }
  for (const it of res.items) box.append(card(it));
  st.seen = [...new Set([...res.items.map((i) => i.title), ...st.seen])].slice(0, 60);
  store.set("seen", st.seen);
  box.scrollIntoView({ behavior: "smooth", block: "start" });
}

function say(text, err) { const m = $("msg"); m.textContent = text || ""; m.classList.toggle("err", !!err); }

let running = null;
async function submit(ev) {
  ev.preventDefault();
  const x = t();
  const age = parseInt($("age").value, 10);
  if (!(age >= 1 && age <= 120)) return say(x.needAge, true);
  if (!st.services.size) return say(x.needServ, true);
  store.set("age", age); store.set("country", $("country").value);

  const on = $("rateOn").checked, { lo, hi } = rateState();
  const body = {
    region: $("country").value, lang: st.lang, age, kind: st.kind,
    services: [...st.services], moods: [...st.moods], wish: $("wish").value.trim(),
    rateMin: on ? RATES[lo] : null, rateMax: on ? RATES[hi] : null,
    exclude: st.seen
  };
  if (running) running.abort();
  const ac = running = new AbortController();
  $("go").disabled = true; $("results").textContent = ""; say(x.busy);
  try {
    const res = await fetch("/api/suggest", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), signal: ac.signal });
    if (!res.ok && !(res.body && res.headers.get("content-type").includes("ndjson"))) {
      let code = "agent";
      try { code = (await res.json()).code || code; } catch { /* oletus */ }
      throw Object.assign(new Error(code), { code });
    }
    const reader = res.body.getReader(), dec = new TextDecoder();
    let buf = "", done = false;
    const handle = (line) => {
      if (!line.trim()) return;
      let ev; try { ev = JSON.parse(line); } catch { return; }
      if (ev.t === "status") say(x.status[ev.k] || x.busy);
      else if (ev.t === "result") { done = true; say(""); showResult(ev); }
      else if (ev.t === "error") { done = true; throw Object.assign(new Error(ev.code), { code: ev.code }); }
    };
    for (;;) {
      const { value, done: fin } = await reader.read();
      if (value) { buf += dec.decode(value, { stream: !fin }); const lines = buf.split("\n"); buf = lines.pop(); lines.forEach(handle); }
      if (fin) break;
    }
    handle(buf);
    if (!done) throw Object.assign(new Error("upstream"), { code: "upstream" });
  } catch (e) {
    if (e.name === "AbortError") return;
    say(x.errors[e.code] || x.errors.upstream, true);
  } finally {
    if (running === ac) { running = null; $("go").disabled = false; }
  }
}

/* ---------- käynnistys ---------- */
$("uiLang").onchange = (e) => { st.lang = e.target.value; applyLang(); };
$("rMin").oninput = $("rMax").oninput = drawRate;
$("rateOn").onchange = drawRate;
$("form").addEventListener("submit", submit);
const r0 = store.get("rate", { on: false, lo: 0, hi: 4 });
$("rateOn").checked = !!r0.on; $("rMin").value = r0.lo; $("rMax").value = r0.hi;
const a0 = store.get("age", null); if (a0) $("age").value = a0;
buildServices();
applyLang();
